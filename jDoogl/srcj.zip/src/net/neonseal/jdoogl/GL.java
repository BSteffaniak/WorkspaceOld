package net.neonseal.jdoogl;

import static net.neonseal.jdoogl.GL.beginTextureDraw;
import static net.neonseal.jdoogl.GL.beginVertexDraw;
import static net.neonseal.jdoogl.GL.endTextureDraw;
import static net.neonseal.jdoogl.GL.endVertexDraw;
import static org.lwjgl.opengl.GL11.GL_ALPHA_TEST;
import static org.lwjgl.opengl.GL11.GL_BLEND;
import static org.lwjgl.opengl.GL11.GL_DEPTH_TEST;
import static org.lwjgl.opengl.GL11.GL_FLOAT;
import static org.lwjgl.opengl.GL11.GL_GREATER;
import static org.lwjgl.opengl.GL11.GL_MODELVIEW;
import static org.lwjgl.opengl.GL11.GL_NEAREST;
import static org.lwjgl.opengl.GL11.GL_NICEST;
import static org.lwjgl.opengl.GL11.GL_NORMAL_ARRAY;
import static org.lwjgl.opengl.GL11.GL_ONE;
import static org.lwjgl.opengl.GL11.GL_ONE_MINUS_SRC_ALPHA;
import static org.lwjgl.opengl.GL11.GL_PERSPECTIVE_CORRECTION_HINT;
import static org.lwjgl.opengl.GL11.GL_PROJECTION;
import static org.lwjgl.opengl.GL11.GL_SMOOTH;
import static org.lwjgl.opengl.GL11.GL_TEXTURE_2D;
import static org.lwjgl.opengl.GL11.GL_TEXTURE_COORD_ARRAY;
import static org.lwjgl.opengl.GL11.GL_OR_INVERTED;
import static org.lwjgl.opengl.GL11.glLogicOp;
import static org.lwjgl.opengl.GL11.GL_TEXTURE_MAG_FILTER;
import static org.lwjgl.opengl.GL11.GL_TEXTURE_MIN_FILTER;
import static org.lwjgl.opengl.GL11.GL_VERTEX_ARRAY;
import static org.lwjgl.opengl.GL11.glAlphaFunc;
import static org.lwjgl.opengl.GL11.glBlendFunc;
import static org.lwjgl.opengl.GL11.glClearColor;
import static org.lwjgl.opengl.GL11.glDisableClientState;
import static org.lwjgl.opengl.GL11.glEnable;
import static org.lwjgl.opengl.GL11.glDisable;
import static org.lwjgl.opengl.GL11.glIsEnabled;
import static org.lwjgl.opengl.GL11.glEnableClientState;
import static org.lwjgl.opengl.GL11.glHint;
import static org.lwjgl.opengl.GL11.glLoadIdentity;
import static org.lwjgl.opengl.GL11.glMatrixMode;
import static org.lwjgl.opengl.GL11.glNormalPointer;
import static org.lwjgl.opengl.GL11.glRotatef;
import static org.lwjgl.opengl.GL11.glRotated;
import static org.lwjgl.opengl.GL11.glOrtho;
import static org.lwjgl.opengl.GL11.glShadeModel;
import static org.lwjgl.opengl.GL11.glScissor;
import static org.lwjgl.opengl.GL11.glTexCoordPointer;
import static org.lwjgl.opengl.GL11.glPushMatrix;
import static org.lwjgl.opengl.GL11.glPopMatrix;
import static org.lwjgl.opengl.GL11.glTexParameteri;
import static org.lwjgl.opengl.GL11.glVertexPointer;
import static org.lwjgl.opengl.GL11.glViewport;
import static org.lwjgl.opengl.GL11.glTranslatef;
import static org.lwjgl.opengl.GL11.glTranslated;
import static org.lwjgl.opengl.GL11.GL_COLOR_LOGIC_OP;
import static org.lwjgl.opengl.GL11.glScalef;
//import static org.lwjgl.opengl.GL11.gl
import static org.lwjgl.opengl.GL11.glColor4f;
import static org.lwjgl.opengl.GL11.glScaled;
import static org.lwjgl.opengl.GL11.glDrawArrays;
import static org.lwjgl.opengl.GL11.GL_QUADS;
import static org.lwjgl.opengl.GL11.GL_SCISSOR_TEST;
import static org.lwjgl.opengl.GL15.GL_ARRAY_BUFFER;
import static org.lwjgl.opengl.GL15.glBindBuffer;

import static org.lwjgl.opengl.GL11.*;

import java.awt.Canvas;
import java.nio.FloatBuffer;
import java.util.ArrayList;

import net.neonseal.jdoogl.sprites.SpriteSheet;
import net.neonseal.jdoogl.sprites.Texture;
import net.neonseal.jdoogl.util.Buffer;
import net.neonseal.jdoogl.util.Task;

import org.lwjgl.BufferUtils;
import org.lwjgl.LWJGLException;
import org.lwjgl.input.Keyboard;
import org.lwjgl.openal.AL;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import org.lwjgl.opengl.GL14;

/**
* Class used for accessing many static methods that incorporate
* OpenGL.
* 
* @author Braden Steffaniak
* @since  Fri May 25 10:29:08 AM
*/

public class GL
{
	private static boolean flipped;
	
	private static double  offsets[] = new double[3];
	private static double  scale[]   = new double[ ] { 1, 1, 1 };
	
	private static ArrayList<double[]> tempOffsets = new ArrayList<double[]>();
	private static ArrayList<double[]> tempScale   = new ArrayList<double[]>();
	
	public static SpriteSheet WHITE;
	
	private static Buffer rectVerticesBuffer, rectTexturesBuffer;
	
	private static int    rectVerticesPosition, rectTexturesPosition;
	
	public  static boolean jar;
	
	public  static String path = System.getProperty("java.class.path");
	
	public static void setAmountOfElements(int amount)
	{
		rectVerticesBuffer = new Buffer(amount);
		rectTexturesBuffer = new Buffer(amount);
	}
	
	public static int createRect(float x, float y, float z, float width, float height)
	{
		if (rectVerticesBuffer == null)
		{
			throw new NullPointerException("You must use setAmountOfElements(int amount) before you can create any elements.");
		}
		
		rectVerticesBuffer.addData(addRectVertexArrayf(x, y, z, width, height, 0, null));
		
		rectVerticesBuffer.refreshData();
		
		rectVerticesPosition += 1;
		
		return rectVerticesPosition - 1;
	}
	
	public static void setRectTextureOffsets(int position, float offsets[])
	{
		float textures[] = addRectTextureArrayf(offsets, 0, null);
		
		System.out.println();
		
		rectTexturesBuffer.setData(position * 4 * 2, textures);
		
		rectTexturesBuffer.refreshData();
	}
	
	public static void renderRect(int position)
	{
		if (rectVerticesBuffer == null)
		{
			return;
		}
		
		beginVertexDraw(rectVerticesBuffer.getId(), 3);
		beginTextureDraw(rectTexturesBuffer.getId(), 2);
		
		glDrawArrays(GL_QUADS, position * 4, 4);
		
		endTextureDraw();
		endVertexDraw();
	}
	
	public static void renderRects()
	{
		if (rectVerticesBuffer == null)
		{
			return;
		}
		
		beginVertexDraw(rectVerticesBuffer.getId(), 3);
		beginTextureDraw(rectTexturesBuffer.getId(), 2);
		
		glDrawArrays(GL_QUADS, 0, rectVerticesPosition * 4);
		
		endTextureDraw();
		endVertexDraw();
	}
	
	public static void setColorf(float r, float g, float b, float a)
	{
		glColor4f(r, g, b, a);
	}
	
	public static void setColori(int r, int g, int b, int a)
	{
		glColor4f(r / 255f, g / 255f, b / 255f, a / 255f);
	}
	
	public static void setClearColorf(float r, float g, float b, float a)
	{
		glClearColor(r, g, b, a);
	}
	
	public static void setClearColori(int r, int g, int b, int a)
	{
		glClearColor(r / 255f, g / 255f, b / 255f, a / 255f);
	}
	
	public static void drawQuads(int start, int amount)
	{
		glDrawArrays(GL_QUADS, start * 4, amount * 4);
	}
	
	public static void drawQuadRect(int x, int y, int width, int height, Buffer verticesBuffer, Buffer texturesBuffer, SpriteSheet sprites, int arrayWidth, int arrayHeight)
	{
		beginVertexDraw(verticesBuffer.getId(), 2);
		beginTextureDraw(texturesBuffer.getId(), 2);
		
		sprites.bind();
		
		drawRect(x, y, width, height, 4, arrayWidth, arrayHeight, GL_QUADS);
		
		endTextureDraw();
		endVertexDraw();
	}
	
	public static void drawQuadRect(int x, int y, int width, int height, int arrayWidth, int arrayHeight)
	{
		drawRect(x, y, width, height, 4, arrayWidth, arrayHeight, GL_QUADS);
	}
	
//	public static void drawQuad(int x, int y, int z, int width, int height)
//	{
//		glDrawArrays(GL_QUADS, 0, 1);
//	}
	
	private static void drawRect(int x, int y, int width, int height, int stride, int arrayWidth, int arrayHeight, int type)
	{
		if (x + width >= arrayWidth)
		{
			width = arrayWidth - x;
		}
		if (y + height >= arrayHeight)
		{
			height = arrayHeight - y;
		}
		
		for (int i = y; i < height + y; i ++)
		{
			int dx = x * stride + (i * stride * arrayWidth);
			
			glDrawArrays(type, dx, width * stride);
		}
	}
	
	public static void initGL()
	{
		if (path.indexOf(";") >= 0)
		{
			path = System.getProperty("java.class.path");
			
			path = path.substring(path.indexOf(";") + 1, path.indexOf(";", path.indexOf(";") + 1));
			path += System.getProperty("file.separator");
		}
		else
		{System.out.println(path);
			path = path.substring(0, path.lastIndexOf(System.getProperty("file.separator")) + 1);
			jar = true;
		}
		
		setNatives();
	}
	
	private static void setNatives()
	{
		System.setProperty("org.lwjgl.librarypath", path + "natives");
	}
	
	public static void beginManipulation()
	{
		tempOffsets.add(offsets.clone());
		tempScale.add  (scale.clone());
		
		glPushMatrix();
	}
	
	public static void endManipulation()
	{
		double temp[] = tempOffsets.get(tempOffsets.size() - 1);
		
		offsets[0] = temp[0];
		offsets[1] = temp[1];
		offsets[2] = temp[2];
		
		tempOffsets.remove(tempOffsets.size() - 1);
		
		
		temp = tempScale.get(tempScale.size() - 1);
		
		scale[0] = temp[0];
		scale[1] = temp[1];
		scale[2] = temp[2];
		
		tempScale.remove(tempScale.size() - 1);
		
		glPopMatrix();
	}
	
	public static void enableClipping()
	{
		glEnable(GL_SCISSOR_TEST);
	}
	
	public static void endClipping()
	{
		glDisable(GL_SCISSOR_TEST);
	}
	
	public static void enableInverting()
	{
		glEnable(GL_COLOR_LOGIC_OP);
	}
	
	public static void endInverting()
	{
		glDisable(GL_COLOR_LOGIC_OP);
	}
	
	public static void beginInverting()
	{
		enableInverting();
		
		/*
		 * GL_CLEAR
		 * GL_SET
		 * GL_COPY
		 * GL_COPY_INVERTED
		 * GL_NOOP
		 * GL_INVERT
		 * GL_AND
		 * GL_NAND
		 * GL_OR
		 * GL_NOR
		 * GL_XOR
		 * GL_EQUIV
		 * GL_AND_REVERSE
		 * GL_AND_INVERTED
		 * GL_OR_REVERSE
		 * GL_OR_INVERTED 
		 */
		
		glLogicOp(GL_COPY_INVERTED);
	}
	
	public static void beginInvertingBackground()
	{
		enableInverting();
		
		/*
		 * GL_CLEAR
		 * GL_SET
		 * GL_COPY
		 * GL_COPY_INVERTED
		 * GL_NOOP
		 * GL_INVERT
		 * GL_AND
		 * GL_NAND
		 * GL_OR
		 * GL_NOR
		 * GL_XOR
		 * GL_EQUIV
		 * GL_AND_REVERSE
		 * GL_AND_INVERTED
		 * GL_OR_REVERSE
		 * GL_OR_INVERTED 
		 */
		
		glLogicOp(GL_INVERT);
	}
	
	public static void beginXOR()
	{
		enableInverting();
		
		/*
		 * GL_CLEAR
		 * GL_SET
		 * GL_COPY
		 * GL_COPY_INVERTED
		 * GL_NOOP
		 * GL_INVERT
		 * GL_AND
		 * GL_NAND
		 * GL_OR
		 * GL_NOR
		 * GL_XOR
		 * GL_EQUIV
		 * GL_AND_REVERSE
		 * GL_AND_INVERTED
		 * GL_OR_REVERSE
		 * GL_OR_INVERTED 
		 */
		
		glLogicOp(GL_NOR);
	}
	
	public static void beginClipping(int x, int y, int width, int height)
	{
		enableClipping();
		
		glScissor(x, y, width, height);
	}
	
	public static void initLighting()
	{
		glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, GL_TRUE);
		
		glEnable(GL_COLOR_MATERIAL);
		glEnable(GL_LIGHTING);
		glEnable(GL_LIGHT0);
		glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, 0);
		glLightModeli(GL_FRONT, GL_DIFFUSE);
		glEnable(GL_NORMALIZE);
	}
	
	public static void startNormal()
	{
		glNormal3f(0, 0, 1);
	}
	
	public static void setLightLocation(float x, float y, float z)
	{
		FloatBuffer pos = BufferUtils.createFloatBuffer(8);
		pos.put(new float[] { x, y, z, 1.0f }).flip();
		
		glLight(GL_LIGHT0, GL_POSITION, pos);
	}
	
	public static void light()
	{
		FloatBuffer amb = BufferUtils.createFloatBuffer(8);
		amb.put(new float[] { -0.2f, -0.2f, -0.2f, 1.0f }).flip();
		
		FloatBuffer dif = BufferUtils.createFloatBuffer(8);
		dif.put(new float[] { 10f, 10f, 10f, 1.0f }).flip();
		
//		FloatBuffer spe = BufferUtils.createFloatBuffer(8);
//		spe.put(new float[] { 0.0f, 0.0f, 0.0f, 1.0f }).flip();
		
		glLight(GL_LIGHT0, GL_AMBIENT, amb);
		glLight(GL_LIGHT0, GL_DIFFUSE, dif);
//		glLight(GL_LIGHT0, GL_SPECULAR, spe);
	}
	
//	public static void setLightProperties()
//	{
//		FloatBuffer black = BufferUtils.createFloatBuffer(8);
//		black.put(new float[] { 0, 0, 0, 1 }).flip();
//		
//		FloatBuffer green = BufferUtils.createFloatBuffer(8);
//		green.put(new float[] { 0, 1, 0, 1 }).flip();
//		
//		FloatBuffer white = BufferUtils.createFloatBuffer(8);
//		white.put(new float[] { 1, 1, 1, 1 }).flip();
//		
//		glMaterial(GL_FRONT, GL_AMBIENT, white);
//		glMaterial(GL_FRONT, GL_DIFFUSE, white);
//		glMaterial(GL_FRONT, GL_SPECULAR, black);
//		
////		glMaterialf(GL_FRONT, GL_SHININESS, 60.0f);
//	}

	public static void rotatef(float x, float y, float z)
	{
		if (x != 0)
		{
			glRotatef(x, 1, 0, 0);
		}
		if (y != 0)
		{
			glRotatef(y, 0, 1, 0);
		}
		if (z != 0)
		{
			glRotatef(z, 0, 0, 1);
		}
	}
	
	public static void rotated(double x, double y, double z)
	{
		if (x != 0)
		{
			glRotated(x, 1, 0, 0);
		}
		if (y != 0)
		{
			glRotated(y, 0, 1, 0);
		}
		if (z != 0)
		{
			glRotated(z, 0, 0, 1);
		}
	}
	
	public static void scalef(float x, float y, float z)
	{
		glScalef(x, y, z);
		
		scale[0] *= x;
		scale[1] *= y;
		scale[2] *= z;
	}
	
	public static void scaled(double x, double y, double z)
	{
		glScaled(x, y, z);
		
		scale[0] *= x;
		scale[1] *= y;
		scale[2] *= z;
	}
	
	public static void translatef(float x, float y, float z)
	{
		glTranslatef(x, y, z);
		
		offsets[0] += x;
		offsets[1] += y;
		offsets[2] += z;
	}
	
	public static void translated(double x, double y, double z)
	{
		glTranslated(x, y, z);
		
		offsets[0] += x;
		offsets[1] += y;
		offsets[2] += z;
	}
	
	public static double[] getAmountTranslated()
	{
		return offsets;
	}
	
	public static double[] getAmountScaled()
	{
		return scale;
	}
	
	public static void renderQuads(Buffer verticesBuffer, Buffer texturesBuffer, SpriteSheet sprites, int start, int amount, Task task)
	{
		renderBuffers(verticesBuffer, texturesBuffer, sprites, start * 4, amount * 4, GL_QUADS, task);
	}
	
	public static void renderQuads(Buffer verticesBuffer, Buffer texturesBuffer, SpriteSheet sprites, int start, int amount)
	{
		renderBuffers(verticesBuffer, texturesBuffer, sprites, start * 4, amount * 4, GL_QUADS);
	}
	
	public static void renderQuads(Buffer verticesBuffer, Buffer texturesBuffer, Buffer normalsBuffer, SpriteSheet sprites, int start, int amount)
	{
		renderBuffers(verticesBuffer, texturesBuffer, normalsBuffer, sprites, start * 4, amount * 4, GL_QUADS);
	}
	
	public static void renderQuads(Buffer verticesBuffer, Buffer texturesBuffer, Texture texture, int start, int amount, Task task)
	{
		renderBuffers(verticesBuffer, texturesBuffer, texture, start * 4, amount * 4, GL_QUADS, task);
	}
	
	public static void renderQuads(Buffer verticesBuffer, Buffer texturesBuffer, Texture texture, int start, int amount)
	{
		renderBuffers(verticesBuffer, texturesBuffer, texture, 2, 2, start * 4, amount * 4, GL_QUADS);
	}
	
	public static void renderQuad(Buffer verticesBuffer, Buffer texturesBuffer, Texture texture)
	{
		renderBuffers(verticesBuffer, texturesBuffer, texture, 2, 2, 0, 4, GL_QUADS);
	}
	
	private static void renderBuffers(Buffer verticesBuffer, Buffer texturesBuffer, SpriteSheet sprites, int start, int amount, int type, Task task)
	{
		beginTextureDraw(texturesBuffer.getId(), 2);
		beginVertexDraw (verticesBuffer.getId(), 2);
		
		sprites.bind();
		
		for (int i = 0; i < amount; i += 4)
		{
			task.run();
			
			glDrawArrays(type, start + i, 4);
		}
		
		endVertexDraw();
		endTextureDraw();
	}
	
	private static void renderBuffers(Buffer verticesBuffer, Buffer texturesBuffer, SpriteSheet sprites, int start, int amount, int type)
	{
		beginTextureDraw(texturesBuffer.getId(), 2);
		beginVertexDraw (verticesBuffer.getId(), 2);
		
		sprites.bind();
		
		glDrawArrays(type, start, amount);
		
		endVertexDraw();
		endTextureDraw();
	}
	
	private static void renderBuffers(Buffer verticesBuffer, Buffer texturesBuffer, Buffer normalsBuffer, SpriteSheet sprites, int start, int amount, int type)
	{
		beginTextureDraw(texturesBuffer.getId(), 2);
		beginVertexDraw (verticesBuffer.getId(), 2);
		beginNormalDraw(normalsBuffer.getId());
		
		sprites.bind();
		
		glDrawArrays(type, start, amount);
		
		endNormalDraw();
		endVertexDraw();
		endTextureDraw();
	}
	
	private static void renderBuffers(Buffer verticesBuffer, Buffer texturesBuffer, Texture texture, int start, int amount, int type, Task task)
	{
		beginTextureDraw(texturesBuffer.getId(), 2);
		beginVertexDraw (verticesBuffer.getId(), 2);
		
		texture.bind();
		
		for (int i = 0; i < amount; i += 4)
		{
			task.run();
			
			glDrawArrays(type, start + i, 4);
		}
		
		endVertexDraw();
		endTextureDraw();
	}
	
	private static void renderBuffers(Buffer verticesBuffer, Buffer texturesBuffer, Texture texture, int textureSize, int vertexSize, int start, int amount, int type)
	{
		beginTextureDraw(texturesBuffer.getId(), textureSize);
		beginVertexDraw (verticesBuffer.getId(), vertexSize);
		
		texture.bind();
		
		glDrawArrays(type, start, amount);
		
		endVertexDraw();
		endTextureDraw();
	}
	
	public static void beginVertexDraw(int id, int vertexSize)
	{
		glEnableClientState(GL_VERTEX_ARRAY);
		
		glBindBuffer(GL_ARRAY_BUFFER, id);
        glVertexPointer(vertexSize, GL_FLOAT, 0, 0);
	}
	
	public static void endVertexDraw()
	{
		glDisableClientState(GL_VERTEX_ARRAY);
	}
	
	public static void beginNormalDraw(int id)
	{
		glEnableClientState(GL_NORMAL_ARRAY);
		
		glBindBuffer(GL_ARRAY_BUFFER, id);
        glNormalPointer(GL_FLOAT, 0, 0);
	}
	
	public static void endNormalDraw()
	{
		glDisableClientState(GL_NORMAL_ARRAY);
	}
	
	public static void beginColorDraw(int id)
	{
		glEnableClientState(GL_COLOR_ARRAY);
		
		glBindBuffer(GL_ARRAY_BUFFER, id);
		glColorPointer(4, GL_FLOAT, 0, 0);
	}
	
	public static void endColorDraw()
	{
		glDisableClientState(GL_COLOR_ARRAY);
	}
	
	public static void beginTextureDraw(int id, int vertexSize)
	{
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
		
		glEnableClientState(GL_TEXTURE_COORD_ARRAY);
		
		glBindBuffer(GL_ARRAY_BUFFER, id);
		glTexCoordPointer(vertexSize, GL_FLOAT, 0, 0);
	}
	
	public static void endTextureDraw()
	{
		glDisableClientState(GL_TEXTURE_COORD_ARRAY);
		
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	}
	
	public static void initBasicView()
	{
		glEnable(GL_TEXTURE_2D);
		
//		glBlendFunc(GL_ONE, GL_ONE);
//		GL14.glBlendEquation(GL14.GL_MAX);
		
		glEnable(GL_BLEND);
		glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);
//		glBlendFunc(GL_DST_COLOR, GL_ONE_MINUS_SRC_ALPHA);
		//glBlendEquation(GL_ADD);
//		GL14.glBlendEquation(GL14.GL_FUNC_ADD);
		
		glEnable(GL_ALPHA_TEST);
		glAlphaFunc(GL_GREATER, 0.1f);
		
		glEnable(GL_DEPTH_TEST);
		
		glEnable(GL_CULL_FACE);
		glCullFace(GL_BACK);
		
//		glShadeModel(GL_SMOOTH); // Enable Smooth Shading
		glClearColor(0.0f, 0.3f, 0.6f, 0.0f); // Blue Background
		
		glViewport(0, 0, Display.getWidth(), Display.getHeight());
		glMatrixMode(GL_PROJECTION); // Select The Projection Matrix
		glLoadIdentity(); // Reset The Projection Matrix

		// Calculate The Aspect Ratio Of The Window
		glOrtho(0, Display.getWidth(), 0, Display.getHeight(), -99999, 99999);
		glMatrixMode(GL_MODELVIEW); // Select The Modelview Matrix

		// Really Nice Perspective Calculations
//		glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
		
//		initLighting();
		
		flipped = false;
	}
	
	public static void resetBasicView()
	{
		glViewport(0, 0, Display.getWidth(), Display.getHeight());
		glMatrixMode(GL_PROJECTION); // Select The Projection Matrix
		glLoadIdentity(); // Reset The Projection Matrix

		// Calculate The Aspect Ratio Of The Window
		glOrtho(0, Display.getWidth(), 0, Display.getHeight(), -99999, 99999);
		glMatrixMode(GL_MODELVIEW); // Select The Modelview Matrix
		
		flipped = false;
	}
	
	public static void flipView()
	{
		glViewport(0, 0, Display.getWidth(), Display.getHeight());
		glMatrixMode(GL_PROJECTION); // Select The Projection Matrix
		glLoadIdentity(); // Reset The Projection Matrix
		
		if (flipped)
		{
			// Calculate The Aspect Ratio Of The Window
			glOrtho(0, Display.getWidth(), 0, Display.getHeight(), -99999, 99999);
		}
		else
		{
			// Calculate The Aspect Ratio Of The Window
			glOrtho(0, Display.getWidth(), Display.getHeight(), 0, -99999, 99999);
		}
		
		glMatrixMode(GL_MODELVIEW); // Select The Modelview Matrix
		
		flipped = !flipped;
	}
	
	public static void createFrame(int width, int height, String title, Canvas drawCanvas)
	{
//		initGL();
		
		boolean hasCanvas = drawCanvas != null;
		
		try
		{
			AL.create();
			
			if (hasCanvas)
			{
				Display.setParent(drawCanvas);
			}
			
			Display.create();
			
			Display.setDisplayMode(new DisplayMode(width, height));
		}
		catch (LWJGLException e)
		{
			e.printStackTrace();
		}
		
		Display.setTitle(title);
		
		if (!hasCanvas)
		{
			Display.setResizable(true);
		}
		
//		Display.setVSyncEnabled(true);
	}
	
	public static void createFrame(int width, int height, Canvas drawCanvas)
	{
		createFrame(width, height, "", drawCanvas);
	}
	
	public static float[] addRectColorArrayf(float r, float g, float b, float a, int offset, float[] array)
	{
		if (array == null)
		{
			array = new float[4 * 4];
			
			offset = 0;
		}
		
		int index = 0;
		
		array[offset + index ++] = r;
		array[offset + index ++] = g;
		array[offset + index ++] = b;
		array[offset + index ++] = a;
		
		array[offset + index ++] = r;
		array[offset + index ++] = g;
		array[offset + index ++] = b;
		array[offset + index ++] = a;
		
		array[offset + index ++] = r;
		array[offset + index ++] = g;
		array[offset + index ++] = b;
		array[offset + index ++] = a;
		
		array[offset + index ++] = r;
		array[offset + index ++] = g;
		array[offset + index ++] = b;
		array[offset + index ++] = a;
		
		return array;
	}
	
	public static float[] addRectVertexArrayf(float x, float y, float z, float width, float height, int offset, float[] array)
	{
		if (array == null)
		{
			array = new float[3 * 4];
			
			offset = 0;
		}
		
		int index = 0;
		
		array[offset + index ++] = x;
		array[offset + index ++] = y;
		array[offset + index ++] = z;
		
		array[offset + index ++] = x + width;
		array[offset + index ++] = y;
		array[offset + index ++] = z;
		
		array[offset + index ++] = x + width;
		array[offset + index ++] = y + height;
		array[offset + index ++] = z;
		
		array[offset + index ++] = x;
		array[offset + index ++] = y + height;
		array[offset + index ++] = z;
		
		return array;
	}
	
	public static float[] addRectVertexArrayf(float x, float y, float width, float height, int offset, float[] array)
	{
		if (array == null)
		{
			array = new float[2 * 4];
			
			offset = 0;
		}
		
		int index = 0;
		
		array[offset + index ++] = x;
		array[offset + index ++] = y;
		
		array[offset + index ++] = x + width;
		array[offset + index ++] = y;
		
		array[offset + index ++] = x + width;
		array[offset + index ++] = y + height;
		
		array[offset + index ++] = x;
		array[offset + index ++] = y + height;
		
		return array;
	}
	
	public static float[] addSquareVertexArrayf(float x, float y, float z, float size, int offset, float[] array)
	{
		if (array == null)
		{
			array = new float[3 * 4];
			
			offset = 0;
		}
		
		int index = 0;
		
		array[offset + index ++] = x;
		array[offset + index ++] = y;
		array[offset + index ++] = z;
		
		array[offset + index ++] = x + size;
		array[offset + index ++] = y;
		array[offset + index ++] = z;
		
		array[offset + index ++] = x + size;
		array[offset + index ++] = y + size;
		array[offset + index ++] = z;
		
		array[offset + index ++] = x;
		array[offset + index ++] = y + size;
		array[offset + index ++] = z;
		
		return array;
	}
	
	public static float[] addSquareVertexArrayf(float x, float y, int size, int offset, float[] array)
	{
		if (array == null)
		{
			array = new float[3 * 4];
			
			offset = 0;
		}
		
		int index = 0;
		
		array[offset + index ++] = x;
		array[offset + index ++] = y;
		
		array[offset + index ++] = x + size;
		array[offset + index ++] = y;
		
		array[offset + index ++] = x + size;
		array[offset + index ++] = y + size;
		
		array[offset + index ++] = x;
		array[offset + index ++] = y + size;
		
		return array;
	}
	
	public static float[] addRectTextureArrayf(SpriteSheet spriteSheet, int x, int y, int z, int width, int height, int offset, float[] array)
	{
		if (array == null)
		{
			array = new float[3 * 4];
			
			offset = 0;
		}
		
		int index = 0;
		
		float offsets[] = spriteSheet.getImageOffsetsf(x, y, width, height);
		
		array[offset + index ++] = offsets[0];
		array[offset + index ++] = offsets[1];
		array[offset + index ++] = 0;
		
		array[offset + index ++] = offsets[2];
		array[offset + index ++] = offsets[1];
		array[offset + index ++] = 0;
		
		array[offset + index ++] = offsets[2];
		array[offset + index ++] = offsets[3];
		array[offset + index ++] = 0;

		array[offset + index ++] = offsets[0];
		array[offset + index ++] = offsets[3];
		array[offset + index ++] = 0;
		
		return array;
	}
	
	public static float[] addRectTextureArrayf(SpriteSheet spriteSheet, int x, int y, int width, int height, int offset, float[] array)
	{
		if (array == null)
		{
			array = new float[2 * 4];
			
			offset = 0;
		}
		
		int index = 0;
		
		float offsets[] = spriteSheet.getImageOffsetsf(x, y, width, height);
		
		array[offset + index ++] = offsets[0];
		array[offset + index ++] = offsets[1];
		
		array[offset + index ++] = offsets[2];
		array[offset + index ++] = offsets[1];
		
		array[offset + index ++] = offsets[2];
		array[offset + index ++] = offsets[3];

		array[offset + index ++] = offsets[0];
		array[offset + index ++] = offsets[3];
		
		return array;
	}
	
	public static float[] addRectTextureArrayf(Texture texture, int offset, float[] array)
	{
		if (array == null)
		{
			array = new float[2 * 4];
			
			offset = 0;
		}
		
		int index = 0;
		
		float offsets[] = texture.getImageOffsetsf();
		
		array[offset + index ++] = offsets[0];
		array[offset + index ++] = offsets[1];
		
		array[offset + index ++] = offsets[2];
		array[offset + index ++] = offsets[1];
		
		array[offset + index ++] = offsets[2];
		array[offset + index ++] = offsets[3];

		array[offset + index ++] = offsets[0];
		array[offset + index ++] = offsets[3];
		
		return array;
	}
	
	public static float[] addRectTextureArrayf(float offsets[], int offset, float[] array)
	{
		if (array == null)
		{
			array = new float[2 * 4];
			
			offset = 0;
		}
		
		int index = 0;
		
		array[offset + index ++] = offsets[0];
		array[offset + index ++] = offsets[1];
		
		array[offset + index ++] = offsets[2];
		array[offset + index ++] = offsets[1];
		
		array[offset + index ++] = offsets[2];
		array[offset + index ++] = offsets[3];

		array[offset + index ++] = offsets[0];
		array[offset + index ++] = offsets[3];
		
		return array;
	}
	
	public static double[] addRectVertexArrayd(double x, double y, double z, double width, double height, int offset, double[] array)
	{
		if (array == null)
		{
			array = new double[3 * 4];
			
			offset = 0;
		}
		
		int index = 0;
		
		array[offset + index ++] = x;
		array[offset + index ++] = y;
		array[offset + index ++] = z;
		
		array[offset + index ++] = x;
		array[offset + index ++] = y + height;
		array[offset + index ++] = z;
		
		array[offset + index ++] = x + width;
		array[offset + index ++] = y + height;
		array[offset + index ++] = z;
		
		array[offset + index ++] = x + width;
		array[offset + index ++] = y;
		array[offset + index ++] = z;
		
		return array;
	}
	
	public static double[] addSquareVertexArrayd(double x, double y, double z, double size, int offset, double[] array)
	{
		if (array == null)
		{
			array = new double[3 * 4];
			
			offset = 0;
		}
		
		int index = 0;
		
		array[offset + index ++] = x;
		array[offset + index ++] = y;
		array[offset + index ++] = z;
		
		array[offset + index ++] = x + size;
		array[offset + index ++] = y;
		array[offset + index ++] = z;
		
		array[offset + index ++] = x + size;
		array[offset + index ++] = y + size;
		array[offset + index ++] = z;
		
		array[offset + index ++] = x;
		array[offset + index ++] = y + size;
		array[offset + index ++] = z;
		
		return array;
	}
	
	public static float[] addRectNormalArrayf(int z, int offset, float[] array)
	{
		if (array == null)
		{
			array = new float[3 * 4];
			
			offset = 0;
		}
		
		int index = 0;
		
		array[offset + index ++] = 0;
		array[offset + index ++] = 0;
		array[offset + index ++] = z;
		
		array[offset + index ++] = 0;
		array[offset + index ++] = 0;
		array[offset + index ++] = z;
		
		array[offset + index ++] = 0;
		array[offset + index ++] = 0;
		array[offset + index ++] = z;
		
		array[offset + index ++] = 0;
		array[offset + index ++] = 0;
		array[offset + index ++] = z;
		
		return array;
	}
	
	public static double[] addSquareVertexArrayd(double x, double y, int size, int offset, double[] array)
	{
		if (array == null)
		{
			array = new double[3 * 4];
			
			offset = 0;
		}
		
		int index = 0;
		
		array[offset + index ++] = x;
		array[offset + index ++] = y;
		
		array[offset + index ++] = x + size;
		array[offset + index ++] = y;
		
		array[offset + index ++] = x + size;
		array[offset + index ++] = y + size;
		
		array[offset + index ++] = x;
		array[offset + index ++] = y + size;
		
		return array;
	}
	
	public static double[] addRectTextureArrayd(SpriteSheet spriteSheet, int x, int y, int z, int width, int height, int offset, double[] array)
	{
		if (array == null)
		{
			array = new double[3 * 4];
			
			offset = 0;
		}
		
		int index = 0;
		
		double offsets[] = spriteSheet.getImageOffsetsd(x, y, width, height);
		
		array[offset + index ++] = offsets[0];
		array[offset + index ++] = offsets[1];
		array[offset + index ++] = 0;
		
		array[offset + index ++] = offsets[2];
		array[offset + index ++] = offsets[1];
		array[offset + index ++] = 0;
		
		array[offset + index ++] = offsets[2];
		array[offset + index ++] = offsets[3];
		array[offset + index ++] = 0;

		array[offset + index ++] = offsets[0];
		array[offset + index ++] = offsets[3];
		array[offset + index ++] = 0;
		
		return array;
	}
	
	public static double[] addRectTextureArrayd(SpriteSheet spriteSheet, int x, int y, int width, int height, int offset, double[] array)
	{
		if (array == null)
		{
			array = new double[2 * 4];
			
			offset = 0;
		}
		
		int index = 0;
		
		double offsets[] = spriteSheet.getImageOffsetsd(x, y, width, height);
		
		array[offset + index ++] = offsets[0];
		array[offset + index ++] = offsets[1];
		
		array[offset + index ++] = offsets[2];
		array[offset + index ++] = offsets[1];
		
		array[offset + index ++] = offsets[2];
		array[offset + index ++] = offsets[3];

		array[offset + index ++] = offsets[0];
		array[offset + index ++] = offsets[3];
		
		return array;
	}
}