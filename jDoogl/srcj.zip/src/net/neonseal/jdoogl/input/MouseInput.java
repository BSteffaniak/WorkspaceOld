package net.neonseal.jdoogl.input;

import org.lwjgl.input.Mouse;

public class MouseInput
{
	public static final int BUTTON0 = 0;
	public static final int BUTTON1 = 1;
	public static final int BUTTON2 = 2;
	
	public static int getX()
	{
		return Mouse.getX();
	}
	
	public static int getY()
	{
		return Mouse.getY();
	}
	
	public static int getDX()
	{
		return Mouse.getDX();
	}
	
	public static int getDY()
	{
		return Mouse.getDY();
	}
	
	public static boolean isButtonDown(int button)
	{
		return Mouse.isButtonDown(button);
	}
	
	public static void setGrabbed(boolean grabbed)
	{
		Mouse.setGrabbed(grabbed);
	}
	
	public static int getDWheel()
	{
		return Mouse.getDWheel();
	}
}