package net.neonseal.jdoogl.components;

import static net.neonseal.jdoogl.components.Frame.Alignment.BOTTOM;
import static net.neonseal.jdoogl.components.Frame.Alignment.CENTER;
import static net.neonseal.jdoogl.components.Frame.Alignment.LEFT;
import static net.neonseal.jdoogl.components.Frame.Alignment.RIGHT;
import static net.neonseal.jdoogl.components.Frame.Alignment.TOP;
import static net.neonseal.jdoogl.GL.beginTextureDraw;
import static net.neonseal.jdoogl.GL.beginVertexDraw;
import static net.neonseal.jdoogl.GL.endTextureDraw;
import static net.neonseal.jdoogl.GL.endVertexDraw;

import static org.lwjgl.opengl.Display.wasResized;
import static org.lwjgl.opengl.GL11.GL_QUADS;
import static org.lwjgl.opengl.GL11.glColor4f;
import static org.lwjgl.opengl.GL11.glDrawArrays;
import static org.lwjgl.opengl.GL11.glPopMatrix;
import static org.lwjgl.opengl.GL11.glPushMatrix;
import static org.lwjgl.opengl.GL11.glScalef;
import static org.lwjgl.opengl.GL11.glTranslatef;

import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.io.File;
import java.util.ArrayList;

import net.neonseal.jdoogl.Color;
import net.neonseal.jdoogl.GL;
import net.neonseal.jdoogl.fonts.TTFont;
import net.neonseal.jdoogl.listeners.ActionListener;
import net.neonseal.jdoogl.listeners.MouseListener;
import net.neonseal.jdoogl.util.Buffer;
import net.neonseal.jdoogl.sprites.SpriteSheet;
import net.neonseal.jdoogl.sprites.Texture;
import net.neonseal.jdoogl.util.FrameLoop;
import net.neonseal.jdoogl.util.FrameTask;
import net.neonseal.jdoogl.util.Intersects;

import org.lwjgl.BufferUtils;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;

import org.newdawn.slick.UnicodeFont.DisplayList;
import org.newdawn.slick.font.GlyphPage;

public abstract class Frame
{
	private static boolean     resized;

	private static short       dfps, fps;
	private static short       leftBuffer, rightBuffer, topBuffer, bottomBuffer;
	
	private static int         oldX, oldY;
	
	private static float       scaleX, scaleY;
	
	private static long        newTime, oldTime;
	
	private static String      fileSeparator = System.getProperty("file.separator");
	
	private static Dimension   originalDimensions, resizedDimensions;
	
	private static TTFont      font;
	
	private static Cursor      cursor;
	
	private static FrameLoop   loop;
	
	private static ArrayList<MouseListener>  mouseListeners;
//	private static ArrayList<ActionListener> actionListeners;
	private static ArrayList<Component>      components;
	
	private static ButtonInfo mouseButtons[];
	
//	private ArrayList<Font>  fonts;
	
	public static enum Alignment
	{
		LEFT, RIGHT, CENTER, TOP, BOTTOM
	}
	
	private static class ButtonInfo
	{
		private boolean released;
		
		private int     buttonId;
		
		public ButtonInfo(int buttonId)
		{
			this.buttonId = buttonId;
			
			this.released = true;
		}
		
		public boolean isReleased()
		{
			return released;
		}
		
		public void setReleased(boolean released)
		{
			this.released = released;
		}
		
		public int getButtonId()
		{
			return buttonId;
		}
		
		public boolean isButtonDown()
		{
			return Mouse.isButtonDown(buttonId);
		}
	}
	
	/**
	* Called when a new Display is created. Calls the initialization
	* method to start it up.
	* 
	* @param width The width of the frame to create.
	* @param height The height of the frame to create.
	*/
	public Frame(int width, int height, String title, Canvas drawCanvas)
	{System.out.println("Path: " + System.getProperty("user.dir"));
		GL.initGL();
		
		mouseListeners     = new ArrayList<MouseListener>();
//		actionListeners    = new ArrayList<ActionListener>();
		components         = new ArrayList<Component>();
		
		originalDimensions = new Dimension(width, height);
		resizedDimensions  = new Dimension(width, height);
		
		scaleX = 1;
		scaleY = 1;
		
		mouseButtons       = new ButtonInfo[3];
		
		for (int i = 0; i < mouseButtons.length; i ++)
		{
			mouseButtons[i] = new ButtonInfo(i);
		}
		
		oldX = Mouse.getX();
		oldY = Mouse.getY();
		
		init(width, height, title, drawCanvas);
		
		setFont(GL.path + "/res/images/font/pixel.ttf", 16);
	}
	
	public static class Cursor
	{
		private int         width, height;
		
		private Buffer      verticesBuffer, texturesBuffer;
		
		private Texture     cursorSprites;
		
		public Cursor(int width, int height, String location, boolean flipped)
		{
			this.width  = width;
			this.height = height;
			
			cursorSprites = new Texture(location, "PNG", flipped);
			
			verticesBuffer = new Buffer(4 * 2);
			texturesBuffer = new Buffer(4 * 2);
			
			verticesBuffer.addData(GL.addRectVertexArrayf(0, 0, width, height, 0, null));
			texturesBuffer.addData(GL.addRectTextureArrayf(cursorSprites, 0, null));
			
			texturesBuffer.refreshData();
			verticesBuffer.refreshData();
		}
		
		public void render()
		{
			GL.beginManipulation();
			{
				GL.beginInvertingBackground();
				
				float offset = 10;
				
				glTranslatef(Mouse.getX(), Mouse.getY() - height + 1, offset);
				
				GL.renderQuads(verticesBuffer, texturesBuffer, cursorSprites, 0, 1);
				
				GL.endInverting();
			}
			GL.endManipulation();
		}
		
		public int getWidth()
		{
			return width;
		}
		
		public int getHeight()
		{
			return height;
		}
	}
	
	/**
	* The initialization method for the Display class. Creates a
	* frame and assigns buffer variables.
	* 
	* @param width
	* @param height
	*/
	private void init(int width, int height, String title, Canvas drawCanvas)
	{
		GL.createFrame(width, height, title, drawCanvas);
		
		GL.initBasicView();
		
		GL.WHITE = new SpriteSheet("res" + fileSeparator + "images" + fileSeparator + "White.png", "PNG", 1, 1, false);
		
		newTime = System.currentTimeMillis();
		oldTime = newTime;
		
		dfps    = 0;
		fps     = 0;
		
		leftBuffer   = (short)(width  / 4);
		rightBuffer  = (short)(width  / 4);
		topBuffer    = (short)(height / 4);
		bottomBuffer = (short)(height / 4);
		
		boolean antiAlias   = true;
		java.awt.Graphics g = GlyphPage.getScratchGraphics();
		
		if (g != null && g instanceof Graphics2D)
		{
			Graphics2D g2d = (Graphics2D)g;
			g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, antiAlias ? RenderingHints.VALUE_ANTIALIAS_ON : RenderingHints.VALUE_ANTIALIAS_OFF);
			g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, antiAlias ? RenderingHints.VALUE_TEXT_ANTIALIAS_ON : RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
		}
		
		//ResourceLoader.addResourceLocation(new ClasspathLocation());
//		ResourceLoader.addResourceLocation(new FileSystemLocation(new File(".")));
	}
	
	public static void setFont(String location, int size)
	{
		font = new TTFont(location, size);
	}
	
	public static void setCursor(Cursor cursor)
	{
		Frame.cursor = cursor;
	}
	
	/**
	* Start the main game loop that runs at all times.
	*/
	public void startLoop(int targetFps)
	{
		init();
		
		loop = new FrameLoop();
		
		loop.start(targetFps, new FrameTask()
		{
			public void run()
			{
				GL.beginManipulation();
				
				if (Display.wasResized())
				{
					resized = true;
					
					GL.resetBasicView();
					
					resizedDimensions = new Dimension(Display.getWidth(), Display.getHeight());
					
					scaleX = (float)resizedDimensions.width  / (float)originalDimensions.width;
					scaleY = (float)resizedDimensions.height / (float)originalDimensions.height;
					
//					Idk.offsetY = System.getProperty("os.name").contains("Mac") ? 23 : 0;
				}
				
				loop();
				
				render();
				
				updateFps();
				
				listenMouse();
				
				if (cursor != null)
				{
					cursor.render();
				}
				
				GL.endManipulation();
			}
		});
	}
	
	public void listenMouse()
	{
		double offsets[] = GL.getAmountTranslated();
		
		double offsetX = offsets[0];
		double offsetY = offsets[1];
		
		for (ButtonInfo info : mouseButtons)
		{
			if (info.isReleased() && info.isButtonDown())
			{
				for (MouseListener listener : mouseListeners)
				{
					listener.onMousePressed(info.getButtonId());
				}
				
				info.setReleased(false);
			}
			else if (!info.isReleased() && !info.isButtonDown())
			{
				for (MouseListener listener : mouseListeners)
				{
					listener.onMouseClicked(info.getButtonId());
					listener.onMouseReleased(info.getButtonId());
				}
				
				info.setReleased(true);
				
				for (int i = 0; i < components.size(); i ++)
				{
					synchronized (components)
					{
						Component component = components.get(i);
						
						if (component instanceof Button)
						{
							Button button = ((Button)component);
							
							if (Intersects.rectangles(Mouse.getX() - 1, getHeight() - Mouse.getY() - 1, 1, 1, (int)((button.getScreenX() + offsetX) * 1), (int)((button.getScreenY() + offsetY) * 1), (int)(button.getWidth() * 1), (int)(button.getHeight() * 1)))
							{
								for (int j = 0; j < button.getActionListeners().size(); j ++)
								{
									synchronized (button.getActionListeners())
									{
										ActionListener actionListener = button.getActionListeners().get(j);
										
										actionListener.onActionPerformed(component);
									}
								}
							}
						}
					}
				}
			}
		}
		for (ButtonInfo info : mouseButtons)
		{
			if (!info.isReleased() && info.isButtonDown() && (oldX != Mouse.getX() || oldY != Mouse.getY()))
			{
				for (MouseListener listener : mouseListeners)
				{
					listener.onMouseDragged(info.getButtonId());
				}
			}
		}
		if (oldX != Mouse.getX() || oldY != Mouse.getY())
		{
			for (MouseListener listener : mouseListeners)
			{
				listener.onMouseMoved();
			}
			
			for (int i = 0; i < components.size(); i ++)
			{
				synchronized (components)
				{
					Component component = components.get(i);
					
					if (component instanceof Button)
					{
						Button button = ((Button)component);
						
						if (Intersects.rectangles(Mouse.getX() - 1, getHeight() - Mouse.getY() - 1, 1, 1, (int)((button.getScreenX() + offsetX) * 1), (int)((button.getScreenY() + offsetY) * 1), (int)(button.getWidth() * 1), (int)(button.getHeight() * 1)))
						{
							button.setMouseOver(true);
						}
						else
						{
							button.setMouseOver(false);
						}
					}
				}
			}
			
			oldX = Mouse.getX();
			oldY = Mouse.getY();
		}
	}
	
	public static void addMouseListener(MouseListener mouseListener)
	{
		mouseListeners.add(mouseListener);
	}
	
//	public static void addActionListener(ActionListener actionListener)
//	{
//		actionListeners.add(actionListener);
//	}
	
	/**
	* Abstract void that is used to initialize stuff.
	*/
	public abstract void init();
	
	/**
	* Abstract void that is used for the loop.
	*/
	public abstract void loop();
	
	/**
	* Abstract void that is used to render objects.
	*/
	public abstract void render();
	
	/**
	* Updates the FPS of the screen.
	*/
	public void updateFps()
	{
		dfps ++;
		
		newTime = System.currentTimeMillis();
		
		if (newTime > oldTime + 1000)
		{
			
			
			fps = dfps;
			
			dfps = 0;
			
			oldTime = newTime;
		}
	}
	
	/**
	* Get the left buffer amount of where the player can reach.
	* 
	* @return The left buffer.
	*/
	public static short getLeftBuffer()
	{
		return leftBuffer;
	}

	/**
	* Set the left buffer amount of where the player can reach.
	*/
	public static void setLeftBuffer(short buffer)
	{
		leftBuffer = buffer;
	}

	/**
	* Get the right buffer amount of where the player can reach.
	* 
	* @return The right buffer.
	*/
	public static short getRightBuffer()
	{
		return rightBuffer;
	}

	/**
	* Set the right buffer amount of where the player can reach.
	*/
	public static void setRightBuffer(short buffer)
	{
		rightBuffer = buffer;
	}

	/**
	* Get the top buffer amount of where the player can reach.
	* 
	* @return The top buffer.
	*/
	public static short getTopBuffer()
	{
		return topBuffer;
	}

	/**
	* Set the top buffer amount of where the player can reach.
	*/
	public static void setTopBuffer(short buffer)
	{
		topBuffer = buffer;
	}

	/**
	* Get the bottom buffer amount of where the player can reach.
	* 
	* @return The bottom buffer.
	*/
	public static short getBottomBuffer()
	{
		return bottomBuffer;
	}

	/**
	* Set the bottom buffer amount of where the player can reach.
	* 
	* @return The bottom buffer.
	*/
	public static void setBottomBuffer(short buffer)
	{
		bottomBuffer = buffer;
	}
	
	public static float getCenterX()
	{
		return (float)Display.getWidth() / 2;
	}
	
	public static float getCenterY()
	{
		return (float)Display.getHeight() / 2;
	}
	
	public static int getFps()
	{
		return fps;
	}
	
	public static int getDFps()
	{
		return dfps;
	}
	
	public static void renderTextBox(float x, float y, String text, Color color, float scale)
	{
		int beginIndex = 0;
		int yoff = 0;
		
		int len = text.length();
		
		int height = font.getHeight(text);
		
//		for (int i = 0; i < len + 1; i ++)
//		{
//			if (font.getWidth(text.substring(beginIndex, i)) * scale2 > 300 || i == len)
//			{
//				String substr = text.substring(beginIndex, i);
//				
//				renderText(x, y + yoff * height * scale2, substr, color, scale);
//				
//				yoff ++;
//				beginIndex = i;
//			}
//		}
		
		for (int i = 0; i < len; i ++)
		{
			
		}
	}
	
	/**
	* Render text to the screen at the specified place with the
	* specified Color.
	* 
	* @param x The x position.
	* @param y The y position.
	* @param text The text to be rendered.
	* @param color The color to render the text in.
	* @param size The size of the text to be rendered.
	* @param beginIndex The index to start drawing the string at.
	* @param endIndex The index of the String to stop drawing it at.
	*/
	public static void renderText(float x, float y, String text, Color color, float scale, int beginIndex, int endIndex)
	{
		if (text.equals("") || text == null)
		{
			return;// null;
		}
		
//		DisplayList d = null;
		
		GL.flipView();
		
		glPushMatrix();
		{
			glScalef(scale, scale, 1);
			
			//font.drawString(x / scale2, y / scale2 + Idk.offsetY / scale2, text, color, beginIndex, endIndex);
//			d = font.drawDisplayList(x / scale, y / scale, text, color, beginIndex, endIndex);
			font.drawString(x / scale, y / scale, text, color, beginIndex, endIndex);
		}
		glPopMatrix();
		
		GL.flipView();
		
		glColor4f(1, 1, 1, 1);
		
		//return new short[] { d.width, d.height };
	}
	
	/**
	* Render text to the screen at the specified place with the
	* specified Color.
	* 
	* @param x The x position.
	* @param y The y position.
	* @param text The text to be rendered.
	* @param color The color to render the text in.
	* @param size The size of the text to be rendered.
	*/
	public static float[] renderText(float x, float y, String text, Color color, float scale)
	{
		renderText(x, y, text, color, scale, 0, text.length());
		
		return new float[] { x, y };
	}
	
	/**
	* Render text to the screen at the specified place with the
	* specified Color.
	* 
	* @param xo The x offset position.
	* @param yo The y offset position.
	* @param text The text to be rendered.
	* @param color The color to render the text in.
	* @param size The size of the text to be rendered.
	* @param halign The horizontal alignment of the text to be
	* 		rendered in the Display.
	*/
	public static float[] renderText(float xo, float yo, String text, Color color, float scale, Alignment halign)
	{
		if (halign == LEFT)
		{
			
		}
		else if (halign == CENTER)
		{
			xo += (int)getCenterX() - ((font.getLegitWidth(text) * scale) / 2);
		}
		else if (halign == RIGHT)
		{
			xo += Display.getWidth() - (font.getLegitWidth(text) * scale);
		}
		
		return renderText(xo, yo, text, color, scale);
	}
	
	/**
	* Render text to the screen at the specified place with the
	* specified Color.
	* 
	* @param xo The x offset position.
	* @param yo The y offset position.
	* @param text The text to be rendered.
	* @param color The color to render the text in.
	* @param size The size of the text to be rendered.
	* @param halign The horizontal alignment of the text to be
	* 		rendered in the Display.
	*/
	public static float[] renderText(float xo, float yo, String text, Color color, float scale, Alignment halign, Alignment valign)
	{
		if (valign == TOP)
		{
			
		}
		else if (valign == CENTER)
		{
			yo += (int)getCenterY() - ((font.getLegitHeight(text) * scale) / 2);
		}
		else if (valign == BOTTOM)
		{
			yo += Display.getHeight() - (font.getLegitHeight(text) * scale);
		}
		
		return renderText(xo, yo, text, color, scale, halign);
	}
	
	public static boolean wasResized()
	{
		boolean res = resized;
		
		resized = false;
		
		return res;
	}
	
	public static int getWidth()
	{
		return Display.getWidth();
	}
	
	public static int getHeight()
	{
		return Display.getHeight();
	}
	
	public static TTFont getFont()
	{
		return font;
	}
	
	public static void add(Component component)
	{
		components.add(component);
	}
	
	public static float getScaleX()
	{
		return scaleX;
	}
	
	public static float getScaleY()
	{
		return scaleY;
	}
	
	public static Cursor getCursor()
	{
		return cursor;
	}
	
	public static void setTitle(String title)
	{
		Display.setTitle(title);
	}
}