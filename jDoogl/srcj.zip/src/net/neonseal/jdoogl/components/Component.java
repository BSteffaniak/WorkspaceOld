package net.neonseal.jdoogl.components;

import net.neonseal.jdoogl.GL;

public abstract class Component
{
	private float x, y;
	private float screenX, screenY;
	private float offsetX, offsetY;
	
	private int   width, height;
	
	public void setSize(int width, int height)
	{
		this.width  = width;
		this.height = height;
	}
	
	public void setLocation(float x, float y)
	{
		setX(x);
		setY(y);
	}
	
	protected void setScreenLocation(float x, float y)
	{
		setScreenX(x);
		setScreenY(y);
	}
	
	public void setOffsetLocation(float x, float y)
	{
		setOffsetX(x);
		setOffsetY(y);
	}
	
	public void move(float dx, float dy)
	{
		this.x += dx;
		this.y += dy;
	}
	
	public int getWidth()
	{
		return width;
	}
	
	public void setWidth(int width)
	{
		this.width = width;
	}
	
	public int getHeight()
	{
		return height;
	}
	
	public void setHeight(int height)
	{
		this.height = height;
	}
	
	public float getX()
	{
		return x;
	}
	
	public void setX(float x)
	{
		this.x = x;
	}
	
	public float getY()
	{
		return y;
	}
	
	public void setY(float y)
	{
		this.y = y;
	}
	
	public void setOffsets()
	{
		double offsets[] = GL.getAmountTranslated();
		
		offsetX = (float)offsets[0];
		offsetY = (float)offsets[1];
	}
	
	public float getOffsetX()
	{
		return offsetX;
	}
	
	public void setOffsetX(float x)
	{
		this.offsetX = x;
	}
	
	public float getOffsetY()
	{
		return offsetY;
	}
	
	public void setOffsetY(float y)
	{
		this.offsetY = y;
	}
	
	public float getScreenX()
	{
		return screenX + offsetX;
	}
	
	protected void setScreenX(float x)
	{
		this.screenX = x;
	}
	
	public float getScreenY()
	{
		return screenY + offsetY;
	}
	
	protected void setScreenY(float y)
	{
		this.screenY = y;
	}
	
	public abstract void render();
}