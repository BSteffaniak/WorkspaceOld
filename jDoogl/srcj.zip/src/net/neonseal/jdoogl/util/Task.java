package net.neonseal.jdoogl.util;

public abstract class Task
{
	public abstract void run();
}