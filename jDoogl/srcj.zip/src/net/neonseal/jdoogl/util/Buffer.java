package net.neonseal.jdoogl.util;

import static org.lwjgl.opengl.GL15.GL_ARRAY_BUFFER;
import static org.lwjgl.opengl.GL15.GL_DYNAMIC_DRAW;
import static org.lwjgl.opengl.GL15.GL_WRITE_ONLY;
import static org.lwjgl.opengl.GL15.glBindBuffer;
import static org.lwjgl.opengl.GL15.glBufferData;
import static org.lwjgl.opengl.GL15.glGenBuffers;
import static org.lwjgl.opengl.GL15.glMapBuffer;
import static org.lwjgl.opengl.GL15.glUnmapBuffer;

import java.nio.BufferOverflowException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import org.lwjgl.BufferUtils;

public class Buffer
{
	private int         id;
	private int         position;
	
	private FloatBuffer buffer;
	private ByteBuffer  mapBuffer;
	
	public Buffer(int size)
	{
//		floats = new float[size];
		
		setBuffer(BufferUtils.createFloatBuffer(size));
		
		init();
	}
	
	private void init()
	{
		id = glGenBuffers();
		glBindBuffer(GL_ARRAY_BUFFER, id);
		glBufferData(GL_ARRAY_BUFFER, buffer, GL_DYNAMIC_DRAW);
		//glBufferSubData(GL_ARRAY_BUFFER, 0, buffer);
		//glBindBuffer(GL_ARRAY_BUFFER, 0);
	}
	
	public void addData(float elements[])
	{
		try
		{
			glBindBuffer(GL_ARRAY_BUFFER, id);
			
			mapBuffer = glMapBuffer(GL_ARRAY_BUFFER, GL_WRITE_ONLY, null);
			
			buffer = mapBuffer.order(ByteOrder.nativeOrder()).asFloatBuffer();
			
			buffer.position(position);
			
			buffer.put(elements);
			
			buffer.rewind();
			
			glUnmapBuffer(GL_ARRAY_BUFFER);
			
			glBindBuffer(GL_ARRAY_BUFFER, 0);
			
			this.position = position + elements.length;
		}
		catch(BufferOverflowException ex)
		{
			ex.printStackTrace();
		}
	}
	
	public void setData(int position, float elements[])
	{
//		this.position = position;
		
		glBindBuffer(GL_ARRAY_BUFFER, id);
		
		mapBuffer = glMapBuffer(GL_ARRAY_BUFFER, GL_WRITE_ONLY, null);
		
		buffer = mapBuffer.order(ByteOrder.nativeOrder()).asFloatBuffer();
		
		buffer.position(position);
		
		buffer.put(elements);
		
		buffer.rewind();
		
		glUnmapBuffer(GL_ARRAY_BUFFER);
		
		glBindBuffer(GL_ARRAY_BUFFER, 0);
	}
	
	public void setData(int position, FloatBuffer elements)
	{
		glBindBuffer(GL_ARRAY_BUFFER, id);
		
		mapBuffer = glMapBuffer(GL_ARRAY_BUFFER, GL_WRITE_ONLY, null);
		
		buffer = mapBuffer.order(ByteOrder.nativeOrder()).asFloatBuffer();
		
		buffer.position(position);
		
		buffer.put(elements);
		
		buffer.rewind();
		
		glUnmapBuffer(GL_ARRAY_BUFFER);
		
		glBindBuffer(GL_ARRAY_BUFFER, 0);
	}
	
	public void refreshData()
	{
		setData(0, buffer);
	}
	
	public float[] getData()
	{
		float dst[] = new float[this.capacity()];
		
		buffer.get(dst);
		
		return dst;
	}
	
	public float get(int index)
	{
		return buffer.get(index);
	}
	
	public FloatBuffer getBuffer()
	{
		return buffer;
	}
	
	public void setBuffer(FloatBuffer buffer)
	{
		this.buffer = buffer;
	}
	
	public int getId()
	{
		return id;
	}
	
	public int capacity()
	{
		return buffer.capacity();
	}
}