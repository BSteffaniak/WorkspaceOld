package net.neonseal.jdoogl.util;

public interface FrameTask
{
	public abstract void run();
}