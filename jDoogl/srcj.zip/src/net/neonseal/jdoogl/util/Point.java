package net.neonseal.jdoogl.util;

public class Point
{
	public float x, y;
	
	public Point()
	{
		
	}
	
	public Point(float x, float y)
	{
		this.x = x;
		this.y = y;
	}
}