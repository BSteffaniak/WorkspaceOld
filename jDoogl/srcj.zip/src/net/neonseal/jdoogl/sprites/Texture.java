package net.neonseal.jdoogl.sprites;

import java.io.File;
import java.io.IOException;

import net.neonseal.jdoogl.GL;

import org.newdawn.slick.opengl.TextureLoader;
import org.newdawn.slick.util.ResourceLoader;

public class Texture
{
	private org.newdawn.slick.opengl.Texture texture;
	private String  location, format;
	private int     width, height;
	private boolean flipped;
	
	public Texture(String location, String format, boolean flipped)
	{
		this.location = location;
		this.format   = format;
		this.flipped  = flipped;
		
		init();
	}
	
	public void init()
	{
		try
		{
			texture = TextureLoader.getTexture(format, ResourceLoader.getResourceAsStream((GL.jar ? GL.path : "") + location), flipped);
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		
		this.width  = texture.getImageWidth();
		this.height = texture.getImageHeight();
	}
	
	public float[] getImageOffsetsf()
	{
		float offsets[] = new float[4];
		
		float w = texture.getWidth();
		float h = texture.getHeight();
		
		offsets[0] = 0;
		offsets[1] = 0;
		offsets[2] = w;
		offsets[3] = h;
		
		return offsets;
	}
	
	public double[] getImageOffsetsd()
	{
		double offsets[] = new double[4];
		
		double w = texture.getWidth();
		double h = texture.getHeight();
		
		offsets[0] = 0;
		offsets[1] = 0;
		offsets[2] = w;
		offsets[3] = h;
		
		return offsets;
	}
	
	public void bind()
	{
		texture.bind();
	}
	
	public int getWidth()
	{
		return width;
	}
	
	public int getHeight()
	{
		return height;
	}
}