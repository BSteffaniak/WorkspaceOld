package net.neonseal.jdoogl.listeners;

import net.neonseal.jdoogl.components.Component;

public interface ActionListener
{
	public abstract void onActionPerformed(Component source);
}